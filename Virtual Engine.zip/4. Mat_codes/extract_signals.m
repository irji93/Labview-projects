% PASAR DATOS DE LA SE�AL DEL PXI A TXT PARA USARSE COMO PRUEBA DE VIs


%% PASAR DE DATOS A TXT PARA ENTRADA DE MODELO 
cd 'D:\5. Motores\1. RH13_sala8\1. Ensayos\procesados\200603'
cic = 2000:3000;
MOD(:,1) = datos.PXI.MAF_SP(cic);
MOD(:,2) = datos.PXI.MF_2(cic);
MOD(:,3) = datos.PXI.SPEED(cic);
MOD(:,4) = datos.PXI.CAM_INT(cic);
MOD(:,5) = datos.PXI.CAM_EXH(cic);
MOD(:,6) = mean(datos.PXI.pint(:,cic));
MOD(:,7) = mean(datos.PXI.pexh(:,cic));
MOD(:,8) = -datos.PXI.SPARK(cic);
try
MOD(:,9) = datos.INCA.AF_ratio(cic)./datos.INCA.AF_ratio_SP(cic);
catch
MOD(:,9) = 1; 
    
end
[M im] = max(datos.PXI.pcyl2);
Ploc = datos.cyl.ang(im);



MOD(:,10) = Ploc(cic);
CE = -22+[((datos.PXI.CAM_EXH))]+360;
cd 'D:\3. Labview Data\3. Virtual engine\4. Mat_codes\1. From experiments'
dlmwrite('850.txt',MOD,'delimiter',',','precision',3)
%%
clear
cd 'D:\3. Labview Data\3. Virtual engine\4. Mat_codes\2. From virtual engine'
data = importdata('Pressure.txt');

data_cyc = importdata('CYCLE.txt');
%%
VVTRGF = data_cyc(:,1);
RGF = data_cyc(:,2);
SA = data_cyc(:,4);
SAc = data_cyc(:,5);
IMEP = data_cyc(:,6);
VVT_op = data_cyc(:,8);
VVT_on = data_cyc(:,9);
SA_op_on = data_cyc(:,10);
VVT_RGF_on = data_cyc(:,11);
Ni  = data_cyc(:,12);
DAT = data_cyc(:,6);
FILT = 80;
VVT_f = filter(ones(FILT,1)/FILT,1,DAT);
VVT_f(1:FILT) = VVT_f(FILT+1);
 
figure;plot(IMEP)
yyaxis right;plot(filter(ones(50,1)/50,1,SA))

 %% 
 
 Pcyl = datos.PXI.pcyl2(:,2344:2348);
 cd 'D:\3. Labview Data\2. Puebas VI'
dlmwrite('P.txt',Pcyl,'delimiter',',','precision',3)

%% Alta frecuencia
f.fmin = 4500;f.fmax = 15000;f.samp = 5;
n = mean(datos.PXI.SPEED);
p = datos.PXI.pcyl2(:,cic);
p = p-mean(p(1:100,:))+1;
[P] = filtpressure(p,n,f);
cd 'D:\3. Labview Data\3. Virtual engine\4. Mat_codes\1. From experiments'
dlmwrite('PRAW.txt',p,'delimiter',',','precision',3)

dlmwrite('Knock_raw.txt',p,'delimiter',',','precision',3)
